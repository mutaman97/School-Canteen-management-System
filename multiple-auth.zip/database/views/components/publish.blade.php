<div class="col-lg-3">
  <div class="single-area">
    <div class="card">
      <div class="card-body">
        <h5>{{ $title }}</h5>
        <hr>
        <div class="btn-publish">
          <button type="submit" class="btn btn-primary col-12 {{ $class }}" id="{{ $id }}"><i class="fa fa-save"></i> {{ $button_text }}</button>
        </div>
      </div>
    </div>
  </div>