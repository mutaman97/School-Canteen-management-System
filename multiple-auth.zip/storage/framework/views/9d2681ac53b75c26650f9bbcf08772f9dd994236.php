<?php $__env->startSection('title',__('Recharge Student Card')); ?>

<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('layouts.backend.partials.headersection',['title'=>__('Recharge Student Card')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4><?php echo e(__('Add Money To Student Card')); ?></h4>
                </div>





                <div class="form-divider"></div>
                <div class="card-body">
                    <div class="current-banlence text-center mb-4">
                        <p class="h4" class="text-dark"><?php echo e(__('Add Balance To Card')); ?></p>

                    </div>
                    <form action="<?php echo e(route('checkout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row mb-4">
                            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Enter Amount')); ?></label>
                            <div class="input-group col-sm-12 col-md-7">
                                
                                <input type="number" required="" step="any" class="form-control" name="amount">
                                <div class="input-group-append">
                                    <span class="input-group-text"><?php echo e(__('AED')); ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-4">
                            <div class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></div>
                            <div class="col-sm-12 col-md-7">
                                <div class="buton-btn float-right">
                                    <button type="submit" class="btn btn-primary btn-lg"><?php echo e(__('Next')); ?></button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>