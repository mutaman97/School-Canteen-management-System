<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar">
  <form class="form-inline mr-auto">
    <ul class="navbar-nav mr-3">
      <li><a href="#" data-toggle="sidebar" class="nav-link collapse_btn nav-link-lg"><i class="fas fa-bars"></i></a></li>

    </ul>
    <div class="search-element"></div>
  </form>










  <ul class="navbar-nav navbar-right">


    <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">

      <img alt="image" src="#"
      class="rounded-circle profile-widget-picture ">

      <div class="d-sm-none d-lg-inline-block"><?php echo e(Auth::user()->name ?? ''); ?></div></a>
      <div class="dropdown-menu dropdown-menu-right">
          <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
        document.getElementById('logout-form').submit();" class="dropdown-item has-icon text-danger">
        <i class="fas fa-sign-out-alt"></i> <?php echo e(__('Logout')); ?>

      </a>
      <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" class="d-none">
        <?php echo csrf_field(); ?>
      </form>
    </div>
  </li>
</ul>
</nav>
