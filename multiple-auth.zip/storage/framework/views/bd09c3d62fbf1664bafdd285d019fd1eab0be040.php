<footer class="main-footer">
    <div class="footer-left">
        <?php echo e(__('Powered By')); ?> <a href="https://aldana-computers.com" class="font-weight-bold" target="_blank" rel="noopener noreferrer"><?php echo e(__('Aldana Computers')); ?></a>&copy; <div class="bullet"></div><?php echo e(__('1997')); ?> - <?php echo e(date('Y')); ?>

    </div>
</footer>
