<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?php echo e(config('app.name')); ?> | <?php echo e(Request::segment(2)); ?></title>
  <!-- Favicon icon -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="icon" type="image/png" href="<?php echo e(asset('uploads/favicon.ico')); ?>"/>

  <!-- General CSS Files -->
  <?php if(Session::get('locale') == 'ar'): ?>
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/rtl/bootstrap.min.css')); ?>">
  <?php else: ?>
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>">
  <?php endif; ?>
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/fontawesome.min.css')); ?>">
  <?php if(Session::get('locale') == 'ar'): ?>
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/rtl-fontawesome.css')); ?>">
  <?php endif; ?>
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/selectric.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap-colorpicker.min.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.css">
  <?php echo $__env->yieldContent('style'); ?>
  <?php echo $__env->yieldPushContent('css'); ?>

  
  
  <link href="<?php echo e(asset('admin/assets/fonts/tajawal/tajawal-font.css')); ?>" rel="stylesheet"/>

  <!-- Template CSS -->
  <?php if(Session::get('locale') == 'ar'): ?>
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/rtl/style.css')); ?>?">
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/rtl/components.css')); ?>">
  <?php else: ?>
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/components.css')); ?>">
  <?php endif; ?>

  <!-- INCLUDE FONTS -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="//fonts.googleapis.com/css?family=Nunito:400,600,700,800" rel="stylesheet">
  
  <link href="<?php echo e(asset('admin/assets/fonts/tajawal/tajawal-font.css')); ?>" rel="stylesheet"/>

  
  <link rel="stylesheet" href="<?php echo e(asset('seller/css/common.css')); ?>">

</head>

<body>
<div id="app">
    <div class="main-wrapper main-wrapper-1">
        <!--- Header Section ---->
        <?php echo $__env->make('layouts.backend.partials.parentheader', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!--- Sidebar Section --->
        <?php echo $__env->make('layouts.backend.partials.parentsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!--- Main Content --->
        <div class="main-content  main-wrapper-1">
            <section class="section">
                <?php echo $__env->yieldContent('head'); ?>
            </section>
                <?php echo $__env->yieldContent('content'); ?>
        </div>

        <?php echo $__env->yieldContent('modal'); ?>

        <!--- Footer Section --->
        <?php echo $__env->make('layouts.backend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
</div>

<input type="hidden" id="language_switch" value="<?php echo e(url('seller/lang/switch')); ?>">
<input type="hidden" class="placeholder_image" value="<?php echo e(asset('admin/img/img/placeholder.png')); ?>">












<input type="hidden" id="base_url" value="<?php echo e(url('/')); ?>">
<input type="hidden" id="site_url" value="<?php echo e(url('/')); ?>">



<!-- General JS Scripts -->
<script src="<?php echo e(asset('admin/assets/js/jquery-3.5.1.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/jquery.nicescroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/bootstrap-colorpicker.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.min.js"></script>


<!-- Template JS File -->
<script src="<?php echo e(asset('admin/assets/js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/jquery.selectric.min.js')); ?>"></script>









<?php echo $__env->yieldContent('script'); ?>
<?php echo $__env->yieldPushContent('script'); ?>
<script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>

<!-- RTL & LTR javascrit -->
<script src="<?php echo e(asset('frontend/assets/js/hc-offcanvas-nav.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/assets/js/script.js')); ?>"></script>





<script>
    $(function() {
        $("div .pos-product-main-content div").niceScroll({
        scrollspeed: 40,
        cursorcolor: "#8d5da7",
        //A smaller value increases the scroll speed. A larger value makes the scroll speed slower.

        });

    });
</script>


<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
</script>



</body>
</html>
