<?php $__env->startSection('title', __('Parent Payments Report')); ?>

<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('layouts.backend.partials.headersection', ['title'=>__('Parent Payments Report')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-6">
                            <form action="<?php echo e(url('/partner/report')); ?>" type="get">
                                <div class="form-row">
                                    <div class="col-lg-5">
                                        <div class="form-group">
                                            <label><?php echo e(__('Start Date')); ?></label>
                                            <input type="date" class="form-control" name="start_date" required="">
                                        </div>
                                    </div>
                                    <div class="col-lg-5">
                                        <div class="form-group">
                                            <label><?php echo e(__('End Date')); ?></label>
                                            <input type="date" class="form-control" name="end_date" required="">
                                        </div>
                                        </div>
                                    <div class="col-lg-2 mt-2">
                                        <button type="submit" class="btn btn-primary mt-4"><i class="fas fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-6 mt-2">
                            <form action="<?php echo e(url('/partner/report')); ?>" type="get">
                                <div class="input-group form-row mt-3">
                                    <input type="text" class="form-control" placeholder="<?php echo e(__('Search ...')); ?>" required=""
                                        name="value" autocomplete="off" value="">
                                    <select class="form-control" name="type">
                                        <option value="price"><?php echo e(__('price')); ?></option>
                                        <option value="getway_name"><?php echo e(__('gateway name')); ?></option>
                                        <option value="trx"><?php echo e(__('trx id')); ?></option>
                                        <option value="plan"><?php echo e(__('plan')); ?></option>
                                    </select>
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="buttons">

                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table" id="table-2">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('SL.')); ?></th>
                                    <th><?php echo e(__('Student Name')); ?></th>
                                    <th><?php echo e(__('Card Number')); ?></th>
                                    <th><?php echo e(__('Charge Amount')); ?></th>

                                    <th><?php echo e(__('Date')); ?></th>
                                    <th><?php echo e(__('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = ($data->currentpage() - 1) * $data->perpage() + 1;
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $name = $student->where('student_code', $value->student_code)->firstOrFail()->student_name;
                                    ?>
                                <tr>
                                        <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($name ?? 'null'); ?></td>

                                    <td><?php echo e($value->card_no ?? 'null'); ?></td>

                                    <td><?php echo e($value->balance ?? 'null'); ?> <?php echo e(__('AED')); ?></td>

                                        <td><?php echo e($value->balance_date ?? 'null'); ?></td>

                                        <td>
                                            <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('parent.report.show', $value->id)); ?>" data-toggle="tooltip" title="<?php echo e(__('View')); ?>"><i class="fas fa-eye"></i> <?php echo e(__('View Details')); ?></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.parentapp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>