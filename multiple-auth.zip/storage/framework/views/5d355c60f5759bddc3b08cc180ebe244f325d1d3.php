<?php $__env->startSection('title', __('Payment Report')); ?>

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>__('Parent Payment Report')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/css/reportshow.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="invoice" id="printableArea">
        <div class="row">
            <div class="col-7">
                <h4 class="display-5"><?php echo e(__('Invoice Number: ')); ?><?php echo e($data->id); ?></h4>
            </div>
            <div class="col-5">
                <h4 class="document-type display-5 text-right"><?php echo e(config('app.name')); ?></h4>
                <p class="text-right"><strong>Today Date : <?php echo e(\Carbon\Carbon::now()->format('M d Y')); ?></strong></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <address>
                    <strong><?php echo e(__('Billed To:')); ?></strong><br>
                    <?php echo e($student->student_parent); ?><br>
                    <?php echo e($student->email); ?><br>
                    <?php echo e($student->mobile ?? null); ?><br>
                </address>
            </div>
            <div class="col-md-6 text-md-right">
                <address>
                    <strong><?php echo e(__('Payment Date:')); ?></strong><br>
                    <?php echo e($data->balance_date); ?><br>
                </address>
            </div>
        </div>
        <table class="table table-bordered">
            <tbody>
                <tr>
                    <th><?php echo e(__('Title')); ?></th>
                    <th><?php echo e(__('Description')); ?></th>
                </tr>













                <tr>
                    <td><?php echo e(__('Student Name')); ?></td>
                    <td><?php echo e($student->student_name); ?></td>
                </tr>
                <tr>
                    <td><?php echo e(__('Amount Charged')); ?></td>
                    <td><?php echo e($data->balance); ?></td>
                </tr>
                <tr>
                    <td><?php echo e(__('Balace Before')); ?></td>
                    <td><?php echo e($data->balance_before); ?></td>
                </tr>
                <tr>
                    <td><?php echo e(__('Balance After')); ?></td>
                    <td><?php echo e($data->balance_after); ?></td>
                </tr>
























            </tbody>
        </table>
    </div>

    <a href="<?php echo e(route('parent.payment-invoice', $data->id)); ?>">
        <button class="btn btn-primary btn-icon icon-left"><i class="fas fa-download"></i>
            <?php echo e(__('Download')); ?>

        </button>
    </a>

    <button class="btn btn-warning btn-icon icon-left printableArea"><i class="fas fa-print"></i>
        <?php echo e(__('Print')); ?>

    </button>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('admin/js/reportshow.js?v=1')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.parentapp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>