<form action="/checkout" method="POST">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <button type="submit" id="checkout-live-button">Checkout</button>
</form>
