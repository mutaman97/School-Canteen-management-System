<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
	<div class="section-header">
		<h1><?php echo e(__('Parent Dashboard')); ?></h1>
	</div>
</section>

<?php if(session('status')): ?>
<div class="alert alert-success">
    <div class="alert-body">
		<button class="close" data-dismiss="alert">
			<span>&times;</span>
		</button>
        <?php echo e(session('status')); ?>

    </div>
</div>
<?php endif; ?>

<?php if($total_active_stores == 0): ?>

<?php endif; ?>







<div class="row">
	<div class="col-lg-4 col-md-6 col-sm-6 col-12">
		<div class="card card-statistic-1">
			<div class="card-wrap float-left">
				<div class="card-header">
					<h4><?php echo e(__('Students')); ?></h4>
				</div>
				<div class="card-body">
					<span id="total_stores"><img src="<?php echo e(asset('uploads/loader.gif')); ?>"></span>
				</div>
			</div>
            <div class="card-icon bg-primary float-right">
				<i class="fas fa-user-friends"></i>
			</div>
		</div>
	</div>

	<div class="col-lg-4 col-md-6 col-sm-6 col-12">
		<div class="card card-statistic-1">
			<div class="card-wrap float-left">
				<div class="card-header">
					<h4><?php echo e(__('Students Total Balance')); ?></h4>
				</div>
				<div class="card-body">
					<span id="fund" class="text-primary"><img src="<?php echo e(asset('uploads/loader.gif')); ?>"></span>
                    <span class="text-primary"><?php echo e(__('AED')); ?></span>
				</div>
			</div>
            <div class="card-icon bg-primary float-right">
				<i class="fas fa-wallet"></i>
			</div>
		</div>
	</div>


	<div class="col-lg-4 col-md-6 col-sm-6 col-12">
		<div class="card card-hero">
			<div class="card-header">
				<div class="card-icon">
					<i class="fas fa-bullhorn"></i>
				</div>
				<h4 id="upcoming_count"></h4>
				<div class="card-description"><?php echo e(__('Low Balance Cards')); ?></div>
			</div>
			<div class="card-body p-0">
				<div class="tickets-list">
					<div class="upcoming_renewals_html"></div>

					<a href="<?php echo e(url('/partner/domain')); ?>" class="ticket-item ticket-more">
						<?php echo e(__('View All')); ?><i class="fas fa-chevron-right"></i>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>
<input type="hidden" id="base_url" value="<?php echo e(url('/')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>
<script>
    var loginConfirmation = "<?php echo e(__('Are you sure want to login with this domainbdgdg?')); ?>";
    var waitText = "<?php echo e(__('Please Wait')); ?>";
    var stockLimitExceeded = "<?php echo e(__('Opps maximum stock limit exceeded')); ?>";
    var productCode = "<?php echo e(__('Product Code')); ?>";
    var cartText = "<?php echo e(__('Add To Cart')); ?>";
    var stockOut = "<?php echo e(__('Out Of Stock')); ?>";
    var sdgText = "<?php echo e(__('SDG')); ?>";
</script>
<script src="<?php echo e(asset('admin/js/merchant.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/merchantdashboard.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.backend.parentapp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>