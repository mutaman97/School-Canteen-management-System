<li class="menu-header"><?php echo e(__('Dashboard')); ?></li>
<li class="<?php echo e(Request::is('parent/dashboard') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('parent.dashboard')); ?>">
        <i class="fas fa-tachometer-alt"></i>
        <span><?php echo e(__('Dashboard')); ?></span>
    </a>
</li>

<li class="menu-header"><?php echo e(__('Deposit')); ?></li>
<li class="<?php echo e(Request::is('parent/deposit') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('parent.depo')); ?>">
        <i class="fas fa-money-check"></i>
        <span><?php echo e(__('Deposit')); ?></span>
    </a>
</li>


<li class="menu-header"><?php echo e(__('Students')); ?></li>

<li class="<?php echo e(Request::is('parent/fund/history/list') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('parent.student.payment')); ?>">
        <i class="fas fa-user-graduate"></i>
        <span><?php echo e(__('Students')); ?></span>
    </a>
</li>



<li class="menu-header"><?php echo e(__('Payments History')); ?></li>
<li class="<?php echo e(Request::is('/parent/report') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('parent.report.index')); ?>">
        <i class="fas fa-chart-bar"></i>
        <span><?php echo e(__('Payment Report')); ?></span>
    </a>
</li>
