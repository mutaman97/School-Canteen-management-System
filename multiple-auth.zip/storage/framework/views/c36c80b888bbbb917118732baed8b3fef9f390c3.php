<?php $__env->startSection('title',__('Recharge Student Card')); ?>

<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('layouts.backend.partials.headersection',['title'=>__('Recharge Student Card')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 col-md-12 col-lg-12">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-<?php echo e(Session::get('type')); ?>"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $students ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-12 col-md-4 col-lg-4">
            
            <div class="pricing pricing-highlight">
                <div class="pricing-padding">
                    <div class="user-item">
                        <img alt="image" src="<?php echo e(url("/assets/img/avatar-1.png")); ?>" class="img-fluid" width="150" height="150">
                        <div class="user-details">
                            <div class="h4 "><?php echo e($student->student_name); ?></div>

                        </div>
                    </div>
                    <div class="h3 text-primary py-4">
                        <div><?php echo e($student->balance); ?>&nbsp;<?php echo e(__('AED')); ?></div>
                    </div>
                    <div class="pricing-details">
                        <div class="h6"><?php echo e(__('Card Number: ' . $student->card_no)); ?></div>
                    </div>
                </div>
                <div class="pricing-cta">
                    <a href="<?php echo e(route('parent.depo', ['student' => $student->id])); ?>"><?php echo e(__('Recharge')); ?><i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No Students Found</p>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.parentapp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>