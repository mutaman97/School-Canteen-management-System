"use strict";
function success()
{
    var url = $('#url').val();
    window.location.href = url+'/partner/fund/payment/select';
}