"use strict";
function success()
{
    $('.fund_section').load(' .fund_section');
}