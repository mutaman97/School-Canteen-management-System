"use strict";
function success(){
  
    var url = $('#store_list_url').val();
    window.location.replace(url);
}