"use strict";
function success(params) {
    var url=$('#domain_index').val();
    window.location=url;
}