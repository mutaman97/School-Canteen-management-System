<footer class="main-footer">
    <div class="footer-left">
        {{ __('Powered By') }} <a href="https://aldana-computers.com" class="font-weight-bold" target="_blank" rel="noopener noreferrer">{{ __('Aldana Computers') }}</a>&copy; <div class="bullet"></div>{{__('1997')}} - {{ date('Y') }}
    </div>
</footer>
