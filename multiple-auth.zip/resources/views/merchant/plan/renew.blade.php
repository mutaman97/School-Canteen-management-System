@extends('layouts.backend.app')
@section('title','Plan renew')
@section('head')
@include('layouts.backend.partials.headersection',['title'=>__('Plan renew')])
@endsection
@section('content')

@endsection