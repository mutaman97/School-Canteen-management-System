<?php

return [
    'pk' => env('STRIPE_PK'),
    'sk' => env('STRIPE_SK'),
];
